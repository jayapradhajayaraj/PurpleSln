using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MusicAlbumAPI.Controllers;
using MusicAlbumAPI.DBContext;
using MusicAlbumAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace xunitTest
{
    public class UnitTest1
    {
        public readonly MusicDbContext _dbContext;
        public readonly AlbumController _controller;

         public UnitTest1(){
           _dbContext = GetDbContext();
           _controller = new AlbumController(_dbContext);
        }
        private static MusicDbContext GetDbContext(){
            var options = new DbContextOptionsBuilder<MusicDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            return new MusicDbContext(options);
        }
        //Case1 to read
        [Fact]
        public async Task GetAlbums_ReturnsOkResult() {   
            var result = await _controller.GetAlbums();
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var albums = Assert.IsAssignableFrom<IEnumerable<Album>>(okResult.Value);
            Assert.Empty(albums);
        }

        //Case2 to create
        [Fact]
        public async Task CreateAlbum_ReturnsCreatedAtActionResult()
        {
            var result = await _controller.CreateAlbum(new Album { Name = "If You Say the Word", Artist = "Rihana", Genre = "pop", ReleaseDate =new DateTime(1991,11, 1), Rating = 3 });
            var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result.Result); 
            Assert.IsType<Album>(createdAtActionResult.Value);
        }

        //Case3 to update
        [Fact]
        public async Task UpdateAlbum_ReturnsNoContent()
        {
            var Testupdate = new Album { 
                Id = 1, Name = "Loud", 
                Artist = "JLo", 
                Genre="pop",
                ReleaseDate=DateTime.Now,
                Rating=3};
            _dbContext.Albums.Add(Testupdate);
            await _dbContext.SaveChangesAsync();
            Testupdate.Artist = "None";
            var result = await _controller.UpdateAlbum(1, Testupdate);
            Assert.IsType<NoContentResult>(result);
        }

        //Case4 to Delete
        [Fact]
        public async Task DeleteAlbum_ReturnsNoContent()
        {
   
            var albumToDelete = new Album
            {
                Name = "Good Girl Gone Bad",
                Artist = "Rihana",
                Genre = "none",
                ReleaseDate = DateTime.Now,
                Rating = 1};
            _dbContext.Albums.Add(albumToDelete);
            await _dbContext.SaveChangesAsync();
            var result = await _controller.DeleteAlbum(albumToDelete.Id);
            Assert.IsType<NoContentResult>(result);
            var delete = await _dbContext.Albums.FindAsync(albumToDelete.Id);
            Assert.Null(delete); 
        }

        //Case5 to search
        [Fact]
        public async Task SearchAlbums_ReturnsFilteredResults()
        {
           var albums = new List<Album>
            {
                new Album { 
                    Name = "Loud", 
                    Artist = "Rihana",
                    Genre = "Rock",
                    ReleaseDate = DateTime.Now, 
                    Rating = 4 },
                new Album {
                    Name = "Unapologetic",
                    Artist = "Rihana",
                    Genre = "Pop",
                    ReleaseDate = DateTime.Now, 
                    Rating = 3 },
                new Album { 
                    Name = "Lets Get Lud", 
                    Artist = "Jennifer Lopez",
                    Genre = "Jazz",
                    ReleaseDate = DateTime.Now,
                    Rating = 5 },
            };
            _dbContext.Albums.AddRange(albums);
            await _dbContext.SaveChangesAsync();

            //var result = await _controller.SearchAlbums("Loud", null, null);
            var result = await _controller.SearchAlbums(name: "Loud", artist: "Rihana", genre: "Rock");
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var searchResult = Assert.IsAssignableFrom<IEnumerable<Album>>(okResult.Value);

            var CompareAlbum = Assert.Single(searchResult);
            Assert.Equal("Loud", CompareAlbum.Name);
            Assert.Equal("Rihana", CompareAlbum.Artist);
            Assert.Equal("Rock", CompareAlbum.Genre);
        }

      
    }


}
